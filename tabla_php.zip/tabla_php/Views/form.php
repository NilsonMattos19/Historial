<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Formulario de Historial</title>
</head>
<body>
    <form action="index.php" method="POST">
        <label for="password">Password:</label>
        <input type="password" name="password" required><br>
        
        <label for="email">Email:</label>
        <input type="email" name="email" required><br>
        
        <label for="idCliente">ID Cliente:</label>
        <input type="number" name="idCliente" required><br>
        
        <label for="actividad">Actividad:</label>
        <input type="text" name="actividad" required><br>
        
        <label for="ip">IP:</label>
        <input type="text" name="ip" required><br>
        
        <label for="dispositivo">Dispositivo:</label>
        <input type="text" name="dispositivo" required><br>
        
        <label for="estado">Estado:</label>
        <input type="text" name="estado" required><br>
        
        <label for="detalles">Detalles:</label>
        <textarea name="detalles" required></textarea><br>
        
        <button type="submit">Registrar</button>
    </form>
</body>
</html>