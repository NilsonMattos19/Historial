<?php
require_once '../Infrastructure/Database.php';

class EditHistorial {
    private $db;

    public function __construct() {
        $this->db = (new Database())->dbConnection();
    }

    public function getHistorial($codigo) {
        $query = "SELECT * FROM historial WHERE codigo = :codigo";
        $stmt = $this->db->prepare($query);
        $stmt->bindParam(':codigo', $codigo);
        $stmt->execute();
        return $stmt->fetch(PDO::FETCH_ASSOC);
    }

    public function updateHistorial($data) {
        $query = "UPDATE historial SET 
                  password = :password, 
                  email = :email, 
                  idCliente = :idCliente, 
                  actividad = :actividad, 
                  ip = :ip, 
                  dispositivo = :dispositivo, 
                  estado = :estado, 
                  detalles = :detalles 
                  WHERE codigo = :codigo";
        $stmt = $this->db->prepare($query);
        $stmt->bindParam(':codigo', $data['codigo']);
        $stmt->bindParam(':password', $data['password']);
        $stmt->bindParam(':email', $data['email']);
        $stmt->bindParam(':idCliente', $data['idCliente']);
        $stmt->bindParam(':actividad', $data['actividad']);
        $stmt->bindParam(':ip', $data['ip']);
        $stmt->bindParam(':dispositivo', $data['dispositivo']);
        $stmt->bindParam(':estado', $data['estado']);
        $stmt->bindParam(':detalles', $data['detalles']);
        return $stmt->execute();
    }
}

$editHistorial = new EditHistorial();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if ($editHistorial->updateHistorial($_POST)) {
        echo "Historial actualizado con éxito. Serás redirigido a la vista de historial.";
        header("Refresh: 3; url=ver_historial.php");
        exit();
    } else {
        echo "Error al actualizar el historial.";
    }
} else {
    $codigo = $_GET['codigo'];
    $historial = $editHistorial->getHistorial($codigo);
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Editar Historial</title>
</head>
<body>
    <h1>Editar Historial</h1>
    <form action="edit.php" method="POST">
        <input type="hidden" name="codigo" value="<?php echo $historial['codigo']; ?>">
        
        <label for="password">Password:</label>
        <input type="password" name="password" value="<?php echo $historial['password']; ?>" required><br>
        
        <label for="email">Email:</label>
        <input type="email" name="email" value="<?php echo $historial['email']; ?>" required><br>
        
        <label for="idCliente">ID Cliente:</label>
        <input type="number" name="idCliente" value="<?php echo $historial['idCliente']; ?>" required><br>
        
        <label for="actividad">Actividad:</label>
        <input type="text" name="actividad" value="<?php echo $historial['actividad']; ?>" required><br>
        
        <label for="ip">IP:</label>
        <input type="text" name="ip" value="<?php echo $historial['ip']; ?>" required><br>
        
        <label for="dispositivo">Dispositivo:</label>
        <input type="text" name="dispositivo" value="<?php echo $historial['dispositivo']; ?>" required><br>
        
        <label for="estado">Estado:</label>
        <input type="text" name="estado" value="<?php echo $historial['estado']; ?>" required><br>
        
        <label for="detalles">Detalles:</label>
        <textarea name="detalles" required><?php echo $historial['detalles']; ?></textarea><br>
        
        <button type="submit">Actualizar</button>
    </form>
</body>
</html>