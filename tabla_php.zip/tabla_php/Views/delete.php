<?php
require_once '../Infrastructure/Database.php';

class HistorialDeleter {
    private $db;

    public function __construct() {
        $this->db = (new Database())->dbConnection();
    }

    public function deleteHistorial($codigo) {
        $query = "DELETE FROM historial WHERE codigo = :codigo";
        $stmt = $this->db->prepare($query);
        $stmt->bindParam(':codigo', $codigo);
        return $stmt->execute();
    }
}

if (isset($_GET['codigo'])) {
    $codigo = $_GET['codigo'];
    $deleter = new HistorialDeleter();

    if ($deleter->deleteHistorial($codigo)) {
        echo "Historial eliminado con éxito. Serás redirigido a la vista de historial.";
    } else {
        echo "Error al eliminar el historial.";
    }
    header("Refresh: 3; url=ver_historial.php"); 
    exit();
}
?>