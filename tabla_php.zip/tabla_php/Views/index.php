<?php
require_once '../Controllers/HistorialController.php';

$controller = new HistorialController();
$controller->create();
