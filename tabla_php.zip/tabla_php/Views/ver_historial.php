<?php
require_once '../Infrastructure/Database.php';

class HistorialViewer {
    private $db;

    public function __construct() {
        $this->db = (new Database())->dbConnection();
    }

    public function displayHistorial() {
        $query = "SELECT * FROM historial";
        $stmt = $this->db->prepare($query);
        $stmt->execute();

        echo "<h1>Historial de Actividades</h1>";
        echo "<table border='1'>
                <tr>
                    <th>Código</th>
                    <th>Password</th>
                    <th>Email</th>
                    <th>ID Cliente</th>
                    <th>Actividad</th>
                    <th>Fecha Actividad</th>
                    <th>IP</th>
                    <th>Dispositivo</th>
                    <th>Estado</th>
                    <th>Detalles</th>
                    <th>Acciones</th>
                </tr>";

        while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
            echo "<tr>
                    <td>{$row['codigo']}</td>
                    <td>{$row['password']}</td>
                    <td>{$row['email']}</td>
                    <td>{$row['idCliente']}</td>
                    <td>{$row['actividad']}</td>
                    <td>{$row['fechaActividad']}</td>
                    <td>{$row['ip']}</td>
                    <td>{$row['dispositivo']}</td>
                    <td>{$row['estado']}</td>
                    <td>{$row['detalles']}</td>
                    <td>
                        <a href='edit.php?codigo={$row['codigo']}'>Editar</a> | 
                        <a href='delete.php?codigo={$row['codigo']}' onclick='return confirm(\"¿Estás seguro de que deseas eliminar este registro?\");'>Eliminar</a>
                    </td>
                </tr>";
        }

        echo "</table>";
    }
}

$viewer = new HistorialViewer();
$viewer->displayHistorial();