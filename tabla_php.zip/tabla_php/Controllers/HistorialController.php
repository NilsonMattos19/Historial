<?php
require_once '../Business/HistorialService.php';

class HistorialController {
    public function create() {
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $historial = new HistorialEntity($_POST);
            $service = new HistorialService();

            if ($service->addHistorial($historial)) {
                echo "Historial registrado con éxito. Serás redirigido a la vista de historial.";
                header("Refresh: 3; url=ver_historial.php"); 
                exit(); 
            } else {
                echo "Error al registrar el historial.";
            }
        }
    }
}