<?php
require_once '../Infrastructure/Database.php';
require_once '../Domain/HistorialEntity.php';

class HistorialService {
    private $db;

    public function __construct() {
        $this->db = (new Database())->dbConnection();
    }

    public function addHistorial(HistorialEntity $historial) {
        $query = "INSERT INTO historial (password, email, idCliente, actividad, fechaActividad, ip, dispositivo, estado, detalles) 
                  VALUES (:password, :email, :idCliente, :actividad, NOW(), :ip, :dispositivo, :estado, :detalles)";
        $stmt = $this->db->prepare($query);
        $stmt->bindParam(':password', $historial->password);
        $stmt->bindParam(':email', $historial->email);
        $stmt->bindParam(':idCliente', $historial->idCliente);
        $stmt->bindParam(':actividad', $historial->actividad);
        $stmt->bindParam(':ip', $historial->ip);
        $stmt->bindParam(':dispositivo', $historial->dispositivo);
        $stmt->bindParam(':estado', $historial->estado);
        $stmt->bindParam(':detalles', $historial->detalles);
        return $stmt->execute();
    }
}