<?php
class HistorialEntity {
    public $codigo;
    public $password;
    public $email;
    public $idCliente;
    public $actividad;
    public $fechaActividad;
    public $ip;
    public $dispositivo;
    public $estado;
    public $detalles;

    public function __construct($data) {
        $this->codigo = $data['codigo'] ?? null;
        $this->password = $data['password'] ?? null;
        $this->email = $data['email'] ?? null;
        $this->idCliente = $data['idCliente'] ?? null;
        $this->actividad = $data['actividad'] ?? null;
        $this->fechaActividad = $data['fechaActividad'] ?? null;
        $this->ip = $data['ip'] ?? null;
        $this->dispositivo = $data['dispositivo'] ?? null;
        $this->estado = $data['estado'] ?? null;
        $this->detalles = $data['detalles'] ?? null;
    }
}